<?php
namespace App\Controllers;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Evento;
class EventoController extends BaseController{
    public function index(Request $request,Response $response){
      $eventos = Evento::orderBy('id','desc')->get();
      echo $this->view->render('admin/evento-listar.html',['eventos'=>$eventos]);
      return $response;
    }
    public function novo(Request $request,Response $response){
        echo $this->view->render('admin/evento-novo.html');
        return $response;
    }
    public function salvar(Request $request,Response $response){
     $dados = $request->getparsedBody();
     if(isset($dados['id'])){
       $evento = Evento::find($dados['id']);
     }else{
       $evento = new Evento();
     }
     $evento->titulo = $dados['titulo'];
     $evento->descricao = $dados['descricao'];
     $evento->dataInicio = $dados['dataInicio'];
     $evento->dataFinal = $dados['dataFinal'];
     $evento->inscricaoInicio = $dados['inscricaoInicio'];
     $evento->inscricaoFinal = $dados['inscricaoFinal'];
     $evento->save();
     return $response->withHeader('Location', URL_BASE.'admin/evento')
     ->withStatus(302);
    }
    public function editar(Request $request,Response $response,$args){
        $id = (int) $args['id'];
        $evento = Evento::find($id);
        echo $this->view->render('admin/evento-editar.html',['evento'=>$evento]);
        return $response;

    }
    public function delete(Request $request,Response $response,$args){
        $id = (int) $args['id'];
        Evento::destroy($id);
        return $response->withHeader('Location', URL_BASE.'admin/evento')
        ->withStatus(302);
    }
}
